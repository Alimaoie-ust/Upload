import fetch from 'node-fetch';

const GH_CONFIG = {
    token: "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",
    owner: "ALI-MAOIE",
    repo: "Yaemori-DB"
};

global.yaemoriDB = {
    users: {},
    qa: {},
    history: {}, // أضفنا التاريخ هنا في الذاكرة
    isSyncing: false,
    
    init: async function() {
        try {
            // أضفنا history.json للقائمة
            const files = ['users.json', 'qa_cache.json', 'history.json'];
            for (const file of files) {
                const res = await fetch(`https://api.github.com/repos/${GH_CONFIG.owner}/${GH_CONFIG.repo}/contents/${file}`, {
                    headers: { "Authorization": `token ${GH_CONFIG.token}` }
                });
                if (res.ok) {
                    const json = await res.json();
                    const content = JSON.parse(Buffer.from(json.content, 'base64').toString());
                    const key = file.split('.')[0].replace('_cache', '');
                    this[key] = content;
                }
            }
            console.log("✅ [Yaemori-DB] تم تحميل البيانات والتاريخ.");
        } catch (e) { console.log("❌ [Yaemori-DB] خطأ في التحميل."); }
    },

    save: async function() {
        if (this.isSyncing) return;
        this.isSyncing = true;
        try {
            const files = [
                { name: 'users.json', data: this.users },
                { name: 'qa_cache.json', data: this.qa },
                { name: 'history.json', data: this.history } // أضفنا التاريخ للحفظ
            ];
            for (const f of files) {
                const url = `https://api.github.com/repos/${GH_CONFIG.owner}/${GH_CONFIG.repo}/contents/${f.name}`;
                const res = await fetch(url, { headers: { "Authorization": `token ${GH_CONFIG.token}` } });
                let sha = res.ok ? (await res.json()).sha : undefined;

                await fetch(url, {
                    method: 'PUT',
                    headers: { "Authorization": `token ${GH_CONFIG.token}` },
                    body: JSON.stringify({
                        message: "Sync History & Data",
                        content: Buffer.from(JSON.stringify(f.data, null, 2)).toString('base64'),
                        sha
                    })
                });
            }
        } catch (e) { console.log("❌ [Yaemori-DB] خطأ في المزامنة."); }
        this.isSyncing = false;
    }
};

global.yaemoriDB.init();
export default {};
